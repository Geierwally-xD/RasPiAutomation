#!/bin/bash
sudo gdbserver $*
